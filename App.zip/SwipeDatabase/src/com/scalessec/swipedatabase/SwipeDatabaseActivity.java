package com.scalessec.swipedatabase;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class SwipeDatabaseActivity extends Activity {
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);
        
        SwipeView swipeView = new SwipeView(this);
        swipeView.setOnTouchListener(new View.OnTouchListener() {
        	@Override
        	public boolean onTouch(View v, MotionEvent event) {
        		((SwipeView)v).touch(event);
        		return true;
        	}
        });
       
        setContentView(swipeView);
    }
   
}