package com.scalessec.swipedatabase;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class Helper extends SQLiteOpenHelper{
	Context context;

	public Helper(Context context) {
		super(context, "base.db", null, 1);
		this.context = context;
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		//an array of five strings
		String statements[] = {
			"CREATE TABLE cars ("
				+ "_id INTEGER PRIMARY KEY AUTOINCREMENT,"
				+ "make TEXT,"
				+ "model TEXT,"
				+ "year INTEGER"
				+ ");",
			
			"INSERT INTO cars (make, model, year) values ('Buick', 'Skylark', 1967);",
			"INSERT INTO cars (make, model, year) values ('Acura', 'Integra', 1999);",
			"INSERT INTO cars (make, model, year) values ('Ford', 'Mustang', 2007);",
			"INSERT INTO cars (make, model, year) values ('Chevy', 'Camaro', 2011);",
			"INSERT INTO cars (make, model, year) values ('Toyota', 'Camry', 1988);"
			
		};
		
		for (String statement: statements) {
			db.execSQL(statement);
		}
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	}
	
	public Cursor getCars() {
		//can say _id, name instead of *
		String sql = "SELECT * FROM cars;";
		SQLiteDatabase db = getReadableDatabase();
		Cursor cursor = db.rawQuery(sql, null);
		
		cursor.moveToFirst();
		return cursor;
	}
}

