package com.scalessec.swipedatabase;
import java.util.Timer;
import java.util.TimerTask;

import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.TextView;


public class SwipeView extends TextView {

	int width, height;		//in pixels of the SwipeView
	
	MotionEvent downEvent;	//start of swipe
	MotionEvent moveEvent;	//current location of swipe

	int index;				//position in the database
	
	private Timer leftTimer;
	private Timer rightTimer;
	
	Boolean canSwipeLeft;
	Boolean canSwipeRight;
	
	Helper helper;
	
	public SwipeView(Context context) {
		super(context);
		
		index = -1;
		canSwipeLeft = true;
		canSwipeRight = true;
		
		helper = new Helper(context);
		
		setTextSize(20);	//default is 14
		setText("Swipe left or right to cycle through records in the database.");
	}
	
	public void touch(MotionEvent event) {
		switch(event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			downEvent = MotionEvent.obtain(event);	//copy it
			return;
			
		case MotionEvent.ACTION_UP:
			downEvent = null;
			return;
			
		case MotionEvent.ACTION_MOVE:
			moveEvent = event;
			break;
			
		default:
			return;
		}
		
		final float horizontal = moveEvent.getX() - downEvent.getX();
		final float vertical = moveEvent.getY() - downEvent.getY();
		final float distance = (float)Math.hypot(horizontal, vertical);
		final float angle = (float)(Math.atan2(-vertical, horizontal) * 180 / Math.PI);
//		final float duration = (moveEvent.getEventTime() - downEvent.getEventTime()) / 1000.0f;


		
		if (distance < 50) {
			//ignore - too short
		} else if (angle <= -135) {
			swipeLeft();
		} else if (angle <= -45) {
			//ignore - down swipe
		} else if (angle <= 45) {
			swipeRight();
		} else if (angle <= 135) {
			//ignore - up swipe
		}
		
		invalidate();
	}
	
	public void swipeLeft() {
		Log.d("Swipe", "left swipe");
		
		//stop swipeLeft() from being fired multiple times in one swipe
		canSwipeLeft = false;
		
		leftTimer = new Timer();
		leftTimer.schedule(new TimerTask() {
			@Override
			public void run() {
				leftTimerComplete();
			}

		}, 0, 1000);
		
		Cursor cursor = helper.getCars();
		
		index++;
		if(index > cursor.getCount() - 1 ) {
			index=0;
		}
		
		cursor.move(index);
		
		String result = "";
		
		//start at 1 to skip the _id column
		for(int i=1; i<cursor.getColumnCount(); i++) {
			result += cursor.getColumnName(i) + ":\n" + cursor.getString(i) + "\n\n";
		}

		setText(result);
	}
	
	public void swipeRight() {
		Log.d("Swipe", "right swipe");
		
		//stop swipeRight() from being fired multiple times in one swipe
		canSwipeRight = false;
		
		rightTimer = new Timer();
		rightTimer.schedule(new TimerTask() {
			@Override
			public void run() {
				rightTimerComplete();
			}

		}, 0, 1000);
		
		Cursor cursor = helper.getCars();
		
		index--;
		if(index < 0) {
			index=cursor.getCount() - 1;
		}
		
		cursor.move(index);
		
		String result = "";
		
		//start at 1 to skip the _id column
		for(int i=1; i<cursor.getColumnCount(); i++) {
			result += cursor.getColumnName(i) + ":\n" + cursor.getString(i) + "\n\n";
		}

		setText(result);
	}
	
	public void leftTimerComplete() {
		Log.d("leftTimer", "Left timer complete.");
		leftTimer.cancel();
		canSwipeLeft = true;
	}
	
	public void rightTimerComplete() {
		Log.d("rightTimer", "Right timer complete.");
		rightTimer.cancel();
		canSwipeRight = true;
	}
}